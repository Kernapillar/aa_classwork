class Visit < ApplicationRecord

    
end
